import { NextResponse } from "next/server";
import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";


/**
 * Coin balance for the signed-in user, read from the coins API.
 *
 * Configure with:
 *   JN_COINS_API_URL  e.g. https://api.example.com/coins?discord={discordId}&uuid={uuid}
 *                     ({discordId} and {uuid} are substituted and URL-encoded)
 *   JN_COINS_API_KEY  optional, sent as "Authorization: Bearer <key>"
 *
 * Expected response: JSON with a number at `coins`, `balance`, `amount`,
 * `data.coins` or `data.balance`. Nothing is estimated when the API is unavailable.
 */
export async function GET() {
  const session = await auth();
  const userId = (session?.user as { id?: string } | undefined)?.id;
  if (!userId) return NextResponse.json({ state: "signed-out" }, { status: 401 });

  const template = process.env.JN_COINS_API_URL;
  if (!template) return NextResponse.json({ state: "unconfigured" });

  const [account, link] = await Promise.all([
    prisma.account.findFirst({ where: { userId, provider: "discord" } }),
    prisma.minecraftLink.findUnique({ where: { userId } }),
  ]);

  if (template.includes("{uuid}") && !link?.uuid) {
    return NextResponse.json({ state: "unlinked" });
  }

  const url = template
    .replaceAll("{discordId}", encodeURIComponent(account?.providerAccountId ?? ""))
    .replaceAll("{uuid}", encodeURIComponent(link?.uuid ?? ""));

  try {
    const headers: Record<string, string> = { accept: "application/json" };
    if (process.env.JN_COINS_API_KEY) {
      headers.authorization = `Bearer ${process.env.JN_COINS_API_KEY}`;
    }
    const res = await fetch(url, {
      headers,
      cache: "no-store",
      signal: AbortSignal.timeout(5000),
    });
    if (!res.ok) return NextResponse.json({ state: "error" });

    const data = (await res.json()) as Record<string, unknown> & {
      data?: Record<string, unknown>;
    };
    const candidates = [
      data.coins,
      data.balance,
      data.amount,
      data.data?.coins,
      data.data?.balance,
    ];
    const raw = candidates.find(
      (c) => typeof c === "number" || (typeof c === "string" && c.trim() !== ""),
    );
    const value = typeof raw === "string" ? Number(raw) : raw;
    if (typeof value !== "number" || !Number.isFinite(value)) {
      return NextResponse.json({ state: "error" });
    }
    return NextResponse.json({ state: "ok", coins: value });
  } catch {
    return NextResponse.json({ state: "error" });
  }
}
